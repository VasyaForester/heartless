# Observing an Arena operation

Use this reference when a changed UI or interrupted request makes attribution uncertain. It defines evidence to collect, not fixed selectors or a reason to send a new request.

## Response ownership

Prefer a message/conversation identifier exposed by the current UI. Otherwise use the selected conversation, message role, enclosing component, and order relative to the sent message together. Record the fallback and its uncertainty. Do not search all prose elements and assume the last one is the assistant's answer.

Check the candidate element against neighboring messages and the criteria/judge panels. A model name appearing in text is not a reliable boundary: names can occur inside the response. Save the full attributed response; a tail or snippet is only a display convenience.

## Completion

Look for the page's current generation state and terminal status. A stable text snapshot alone does not establish completion. Capture any explicit error. If completion cannot be established, use pending or unknown rather than synthesizing a refusal, empty answer, or failed criterion.

## Submission uncertainty

Before a judge action, note any existing result and the attempt it belongs to. After the action, require a new result associated with that attempt. If the connection fails, re-read the same conversation and judge state. Do not click again merely because the local wait expired. If the UI cannot distinguish the old and new result, report the ambiguity and preserve the evidence.

## Minimal checkpoint

Record the timestamp, board/scenario/model, conversation or attempt identifier when available, last completed step, pending action, source record path, and the next read-only check. Keep secrets and browser session tokens out of checkpoints. This checkpoint is a human-readable recovery note; it is not an automatic resume API.
