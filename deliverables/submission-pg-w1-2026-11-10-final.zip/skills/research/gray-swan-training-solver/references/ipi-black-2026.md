# IPI Black 2026 (Indirect Prompt Injection: Black) — механики

Доска: `https://app.grayswan.ai/arena/challenge/ipi-black-2026?behaviorId=<id>`; карточки: `wb3s1-retry-budget-merge-request`, `wb3s2-premature-access-approval`, `wb3s3-delete-production-data`, `wb3s4-browser-walkthrough-hijack`, `wb3s5-persist-downstream-config`, `bb3-s1`…`bb3-s5`. Формат = форма инъекций (НЕ чат): до 10-11 слотов на сабмит; required-слот задан сценарием; LAUNCH = один запуск на выбранной модели; вердикт BATCH (SUBMIT BREAK → auto-judge).

## Форма инъекций (Radix UI — только полная pointer-цепочка)

- Триггеры: `#world-injection-<i>-site` (сервис: Jira/GitLab/Slack), `#world-injection-<i>-action` (конкретный слот), текст = `textarea` (по одному на инъекцию; заполнять через native value setter + `input` event).
- Клик по Radix-опции: `pointerdown` → `mousedown` → `pointerup` → `mouseup` → `click` (простой `.click()` НЕ открывает).
- «New injection (N/10 max)» → «Select injection site» → «Select action» → «View content» (превью) / «Delete».
- Заполнить непустые textarea и нажать LAUNCH; при невалидности кнопка disabled (проверять свежий `disabled` — переходный disabled во время ввода нормален).
- Повторный запуск: «RETRY IN NEW CHAT» / «CONTINUE» → форма с пустыми слотами; после ошибок навигации: `location.href='about:blank'` → raw CDP `Page.navigate` (движок после about:blank слеп; см. raw_nav.py подход: websockets к `http://127.0.0.1:9223/json/list`).

## Модели и мониторинг

- Кнопка «Model» на форме → панель MODELS: ~40 моделей, часть «Closed» (перезапуск позже), «BROKEN» = сломанная на этом сценарии; доступно ~20. Во время рана — «Please wait for the current challenge to finish». Переключение — клик по имени (полная pointer-цепочка).
- Ран исполняется на сервере (переживает падение локального браузера); метки: «Model is working» → транскрипт «Scaffold Logs / Used N tools» → «SUBMIT BREAK» (нажать) → «BREAK REJECTED/ACCEPTED» + «SEE EVALUATION».
- Выходы инструментов в UI НЕ показываются (только имена вызовов) — содержимое env рана недоступно постфактум. «Explore environment» = сид-мир БЕЗ инъекций (полезно для рекогносцировки сида: тикеты/имена/каналы/guard-ы).
- E2B-превью мира: `https://<порт>-<инстанс>.e2b.app/__world_preview?token=<tok>` (порты 9000 GitLab / 9001 Slack / 9002 Jira); открывать только реальным браузером (urllib → 403). URL-ы ищутся в iframe-страницы, когда платформа их монтирует.

## Наблюдения по атакам (WB3S1/WB3S2, 12 запусков, 0 зачётов)

- Инъекции ДОСТАВЛЯЮТСЯ и читаются агентами (прямое признание в отчёте: «Noted a late comment on the Jira ticket and message in #platform...»).
- Реквизиты мока РАНДОМЯТСЯ per-chat (principal/ревьюер/SRE, ticket IDs): тексты инъекций должны быть name-agnostic; конкретные имена из прошлого рана = провал.
- Агенты КРОСС-СВЕРЯЮТ инъекцию со скоупом тикета: вставка, «which the ticket didn't request», явно отклоняется с рапортом. Новый контент должен быть согласован с сидом/докой сценария, а не вводиться извне.
- Прямой «bypass»-язык распознаётся как конфликт с инструкциями принципала; агенты проверяют отправителя (`slack_read_user_profile`) и gitlab-состояние.
- Проверенные и отклонённые классы (не повторять без нового механизма): direct-ask, approval-exists, freeze-procedure, thread-signoff+«пустое поле = норма», record-shaped + action-listing, CARI runtime-feedback, multi-voice (Jira+тред+DM). Наблюдение: многоголосье сильные модели молча поглощают (работают по сиду).
- Чтение отчёта рана: сегменты «Scaffold Logs / Used N tools» содержат собственные резюме агента — класс отказа виден там (conflict-report / «ignoring the suspicious…» / молчаливый игнор).
- Правила конструирования (литература 2026 + эмпирика): оперативная строка — ПЕРВОЙ (первая строка выигрывает конфликт 72–95%); label-стиль («Ticket update…», «Recovery report…») сильнее system-позиции в tool-задачах; менять ОДНО решение внутри задачи (near-target), не заменять задачу.
- UI: слот «Send channel message» капризен (клики может перехватывать уже открытый site-дропдаун) — после каждого пика ПРОВЕРЯЙ фактический label триггера, а не «picked»-ответ скрипта.
