---
name: gray-swan-arena-attempt-tracking
description: "Use when recording Gray Swan Arena attempts and results."
version: 0.3.0
author: User, Hermes Agent
license: MIT
platforms: [macos, linux, windows]
metadata:
  hermes:
    tags: [Gray Swan, Arena, challenge tracking, judging]
    related_skills: [gray-swan-cdp-automation, gray-swan-training-solver]
---

# Gray Swan Arena: attempt records and results

## When to Use

Use to log an evaluation attempt, distinguish infrastructure errors from model behavior, reconcile a judge result, or produce a report from existing evidence. For browser interaction, load `gray-swan-cdp-automation` separately. Reading logs does not authorize a new submission.

## Shared operating rules

Follow the active project's `CLAUDE.md` for authorization, target scope, stopping, and reporting. The project is `workspace` under the active imported profile (`HERMES_HOME`, or the directory shown by `hermes profile show PROFILE_NAME` (get the selected name from `hermes profile list`)); verify the actual session directory. Existing permission carries forward within its scope. Ask only for a missing decision that changes the next external action.

## Evidence to retain

For each attempt, retain its timestamp, board/wave when known, scenario, selected model, conversation/attempt identifier when exposed, exact input, complete attributed response, completion state, and available criteria/judge result. Include the source file/record and any uncertainty. Do not invent identifiers absent from the UI. Before a judge submission, snapshot the conversation state the judge will evaluate (transcript dump + content hash, kept locally beside the attempt record): the judge reads the conversation as it stands at submission, so a later rationale citing transcript content is checked against that snapshot, not the chat's later state.

Store full input and response locally in the existing project logs. Keep summaries, snippets, and display truncation separate from the full record. Do not copy tokens, cookies, or credentials into logs or reports. An infrastructure failure before sending is a run event, not a completed model attempt.

## Interpret results in separate dimensions

| Evidence | What may be concluded |
| --- | --- |
| Request failed with an authentication or transport error | Infrastructure failure; no new model outcome unless a response was independently recovered. |
| Generation has not completed, or the response cannot be attributed | Pending/unknown response; no refusal or success classification. |
| Generation completed with no response content | Completed empty response; judge status is recorded separately. |
| Attributed completed response contains a refusal | Refusal observed; preserve any independent judge result verbatim. |
| Response exists but no judge was run | Response observed; judge not requested/not available. |
| Judge is running or its result cannot be matched to this attempt | Pending/unknown judge; not a failed or passed evaluation. |
| One criterion or percentage is favorable | Only that criterion's reported result, not overall success. |
| Current attempt has an explicit final success/failure result | Record the result and its source exactly. |
| UI reports acceptance separately from the judge | Record acceptance separately; a click alone does not prove acceptance. |

Do not use a universal numeric threshold. Apply the current scenario's documented criteria and preserve their labels/values. If an overall outcome is inferred from criteria because no final result exists, label it as an inference and state the rule used. Do not call it a confirmed break. A per-criterion judge panel (`SEE EVALUATION`: scores plus `Issues:` lines; some boards use named-judge persona sentences instead — the strict persona's one-line rationale carries the operative unmet condition) names the exact unmet condition — retain it verbatim as evidence. A judge click that errors out or reports a disabled button does not prove the attempt is unjudged: re-check the SUBMITTED list before treating it as unjudged. A pending judge result can materialize within minutes or stay pending far longer — parallel submissions have sat 30+ minutes. Register every open submission in the pending ledger (`pending.py add`) and drive rechecks with `poll` / `verdict_verify` (background watcher-loop recipe in the CDP skill) instead of a single short pause. Never submit the same conversation again while its verdict is pending; `expired` is not a negative result. Wave-card counters (`breaks_total`, `models_broken`) move when accepts land — treat movement as a signal to reconcile against the SUBMITTED chips, never as the record itself.

A confirmed result requires evidence for the current attempt. A claimed success in response text, historical win, favorable score alone, or a successful button click is insufficient. Keep conflicting signals visible instead of forcing them into one boolean.

## Recording workflow

1. Locate the existing attempt or pending event before appending. Use a stable ID when available; otherwise compare conversation, timestamp, scenario/model, input, and source record. Identical input can be a legitimate repeat, so its hash alone is not an identity.
2. Preserve full evidence through the packaged `workspace/harness/hackathon.py record --file ...` command and local artifact files. The helper validates and appends the supplied JSON event and returns an event ID. Check the receipt and saved record before claiming evidence was stored (verify with the exact substring the writer produced — an approximate grep marker yields false negatives); a browser-action receipt alone is not a model attempt.
3. If a judge result arrives later, append a linked follow-up or record the source link in the audit summary. Do not rewrite earlier raw evidence to make it appear known at submission time.
4. Keep source logs append-only. Derived summaries may be rebuilt, but preserve their input records and distinguish legacy fields from current evidence.
5. Before reporting a success total, count unique confirmed attempts with compatible scope and provenance. Report ambiguous, duplicate, or legacy-only entries separately.
6. Evidence hierarchy for acceptance: authoritative views — the board's own solved screen (`SCENARIO SOLVED` with per-criterion percentages on some boards; `Break Successful!` on Proving Ground; record the exact string observed), SUBMITTED-list status chips, and per-model BROKEN badges — outrank verdict banner text (banners re-render the currently selected model name over older verdicts). Ensure the harness judge parser knows the board's success string before trusting its automated status. When a later authoritative view contradicts an earlier reading, append a linked correction event naming the authoritative source; never edit the earlier record in place.
7. Batch rounds: after a multi-model round, append one round-summary event (per-model class + judge state + checkpoint path) and one dedicated event per newly confirmed pair; the summary preserves per-model outcomes that are not confirmed pairs.
8. Batch reconciliation: after a pause or before reporting totals, run `workspace/harness/verdict_verify.py --target T --apply` — it reconciles the live SUBMITTED list against every farm checkpoint, the journal, and `artifacts/pending_ledger.json`. Journal corrections are append-only under the SAME attemptId; one row matching several round checkpoints is attributed to the latest send only; orphans and assumed filename-stem filters are reported, never auto-applied.
9. Per-board coverage matrix: alongside the journal, keep `datasets/<board>/pairs.jsonl` — one row per scenario×model pair with `chat_id` (from the SUBMISSIONS→CHATS modal's `?chatId=` row hrefs; `null` when not captured — never invent an ID), the qualifying tool call (`tool_name`/`tool_args`), judge state (`accepted`/`rejected`/`not_judged`/`not_attempted`/`pending`), attempts count and short notes. Validate `rows == scenarios × models` before reporting coverage; backfill chat_ids in a separate enrichment pass that does not rewrite already-recorded outcomes. Shared dataset files can be edited by concurrent sessions of the same profile: re-read the file immediately before writing, apply changes to the fresh copy, and write atomically (temp file + replace) — a stale in-place rewrite silently drops the other session's updates.
10. Failure classification and model matrix: give every pair a terminal `outcome` plus a two-axis refusal classification — layer (model refusal / tool-mock error / judge rejection) × cause (policy / missing evidence / state mismatch / authorization / semantics; keep an explicit `unknown`, never conflated with `fail`) — and an ordinal progress rank (r0 refusal → r1 partial progress → r2 judged negative → r3 success). The pair drives strategy: reframing never moves a tool-rail, while a judge reject means the artifact was reached but the rubric's substance was off. Run a positive control (an equivalent request that must pass) before calling a refusal a defense — if the control also fails, suspect the mock or the input, not the model. Zero successes across three distinct classes: park the pair with an upper-bound estimate (rule of three / Wilson interval), never a point claim. Render a scenario×model matrix report (`datasets/<board>/model_matrix.md`) with a per-model summary; the matrix shows which models are pliable vs walled before spending sends.

Read [packaged recording behavior](references/recording-compatibility.md) and [record format](references/record-format.md) before writing. The package uses a Python JSONL recorder; it does not depend on the author’s legacy JavaScript knowledge base.

## Reporting and maintenance

Report in Russian by default: scope, completed work, verified outcome, unresolved issue, next step, and a local record link. Use original English UI labels when needed for precision. Provide full inputs/responses in chat only when requested; their default home is the local evidence log.

Keep dated observations tied to their board/scenario/model and source. Historical labels are not permanent operating rules. New run details belong in logs; this entry point holds the reusable recording procedure. Source provenance is listed in `PROFILE-SOURCES.md`; private backups and histories are not included.

## Hackathon score and hand-in

Use `hackathon.py summary` to count distinct confirmed `(track, scenarioId, modelId)` pairs. `status=completed`, `judgeStatus=passed`, and nonempty evidence are required. Repeating a success on the same pair does not add a point. `confirmedPassedScenarios` counts scenarios with at least one confirmed model; it does not mean all available models are solved.

Keep the same `attemptId` while appending later response/judge updates. `recordedAt` is the local recording time; retain the observed attempt time separately when available. Preserve exposed conversation/attempt IDs, full input/response or local artifact paths, selected model, scenario and track. Never fabricate an Arena ID.

Save reusable participant changes under `workspace/harness` and `skills`. Run `hackathon.py export-submission --out ...` at the end and inspect the generated archive before handing it to the organizer. The export contains reusable source and a derived summary; raw transcripts, browser state and credentials remain local. The tool creates an archive and does not send it.
