# Формат attempt event

Из рабочей папки `workspace` импортированного профиля:

```text
python3 harness/hackathon.py record --file inputs/attempt.json
python3 harness/hackathon.py summary
python3 harness/hackathon.py export-submission --out My-Hackathon-Work.zip
```

На macOS/Linux команда интерпретатора обычно `python3`. JSON-файл создаёт участник/агент из фактически наблюдаемой попытки. Пример ниже только иллюстрирует схему; его не надо добавлять в рабочий журнал:

```json
{
  "attemptId": "participant-defined-unique-id",
  "track": "Chat",
  "scenarioId": "visible-scenario-id",
  "modelId": "visible-model-id",
  "status": "pending",
  "judgeStatus": "pending",
  "judgeEvidence": "",
  "note": "Waiting for the observed run to finish"
}
```

Допустимые треки: `Chat`, `Image`, `Agent`, `Indirect`. После завершения запиши новое событие с тем же attemptId и фактическими status/judgeStatus. Для зачёта нужны `status: completed`, `judgeStatus: passed` и непустая строка judgeEvidence. Если состояние неизвестно — unknown/pending, а не passed. `error` обозначает технический сбой; текст ошибки можно сохранить в локальном поле note.

Журнал — `workspace/attempts/attempts.jsonl`, append-only. Browser operationId и attemptId — разные идентификаторы: несколько подготовительных действий могут относиться к одной попытке. Итоговая сводка удаляет полные ввод/ответ и текст доказательства; она не заменяет локальный evidence. Export не доказывает корректность результата: организатор при необходимости сверяет выбранные пары с доступным подтверждением.
