#!/usr/bin/env python3
"""Fill PPTX text fields by shape-name substring (formatting-preserving).

Usage:
  python3 fill_pptx.py template.pptx out.pptx --map '{"Total Breaks": "10"}'
  python3 fill_pptx.py template.pptx out.pptx --map fields.json --picture "архитектуру харнеса=diagram.png"

--map: JSON (file path or inline string) mapping shape-name substring -> new text.
--picture: repeatable; "shape-name substring=image path" inserts the image over that shape
           (full placeholder bounds; the picture covers the placeholder text on purpose).
Never edits the template; verifies by re-reading the saved file.
"""
from __future__ import annotations
import argparse
import json
import pathlib
import sys
from pptx import Presentation


def set_text_preserve(shape, new):
    """Put text into the first run, blank the others (keeps run 0 formatting)."""
    tf = shape.text_frame
    runs = [r for p in tf.paragraphs for r in p.runs]
    if not runs:
        tf.text = new
        return
    runs[0].text = new
    for r in runs[1:]:
        r.text = ""


def find_all(prs, part):
    hits = []
    for slide in prs.slides:
        for sh in slide.shapes:
            if part.lower() in (sh.name or "").lower():
                hits.append((slide, sh))
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("template")
    ap.add_argument("out")
    ap.add_argument("--map", required=True)
    ap.add_argument("--picture", action="append", default=[],
                    help='"shape-name substring=image.png" (repeatable)')
    a = ap.parse_args()

    mp = pathlib.Path(a.map)
    try:
        is_file = mp.exists()
    except OSError:
        is_file = False
    mapping = json.loads(mp.read_text(encoding="utf-8")) if is_file else json.loads(a.map)

    prs = Presentation(a.template)
    for part, text in mapping.items():
        hits = find_all(prs, part)
        if not hits:
            print(f"WARN: no shape matched {part!r}", file=sys.stderr)
            continue
        set_text_preserve(hits[0][1], text)
    for spec in a.picture:
        part, img = spec.split("=", 1)
        hits = find_all(prs, part)
        if not hits:
            print(f"WARN: no shape matched {part!r} for picture", file=sys.stderr)
            continue
        slide, ph = hits[0]
        slide.shapes.add_picture(img, ph.left, ph.top, ph.width, ph.height)

    prs.save(a.out)
    print("saved:", a.out)

    prs2 = Presentation(a.out)
    for part in mapping:
        hits = find_all(prs2, part)
        if hits:
            print(f"  {part}: {hits[0][1].text_frame.text[:100]}")


if __name__ == "__main__":
    main()
