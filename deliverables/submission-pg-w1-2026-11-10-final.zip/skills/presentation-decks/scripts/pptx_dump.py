#!/usr/bin/env python3
"""Dump a PPTX: slides -> shapes -> text frames/runs (for template mapping).

Usage: python3 pptx_dump.py <file.pptx>
"""
from __future__ import annotations
import sys
from pptx import Presentation


def main():
    fp = sys.argv[1]
    prs = Presentation(fp)
    print(f"slides: {len(prs.slides)}  size: {prs.slide_width}x{prs.slide_height}")
    for si, slide in enumerate(prs.slides):
        print(f"\n===== SLIDE {si + 1} =====")
        for shi, shape in enumerate(slide.shapes):
            pos = (f"L{shape.left} T{shape.top} W{shape.width} H{shape.height}"
                   if shape.left is not None else "?")
            info = f"[{shi}] {shape.name} ({shape.shape_type}) {pos}"
            if shape.has_text_frame:
                print(info)
                for pi, para in enumerate(shape.text_frame.paragraphs):
                    runs = "~".join(r.text for r in para.runs)
                    print(f"    p{pi}: {runs!r}")
            else:
                print(info)


if __name__ == "__main__":
    main()
