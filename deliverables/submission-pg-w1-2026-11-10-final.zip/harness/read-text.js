(() => document.body.innerText)()
