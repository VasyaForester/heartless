#!/usr/bin/env node
// Evaluate a JS expression in the proving-ground tab and print the result.
// Usage: node harness/eval-page.mjs --js "document.title"   (or --jsfile path)
import fs from 'node:fs';
import {assertRuntime, CdpPage, listTargets} from './engine/cdp.mjs';
assertRuntime();
const args = {};
for (let i = 2; i < process.argv.length; i += 2) {
  const k = process.argv[i];
  if (!k.startsWith('--') || !process.argv[i + 1]) throw new Error('Expected --key value pairs.');
  args[k.slice(2)] = process.argv[i + 1];
}
const expr = args.jsfile ? fs.readFileSync(args.jsfile, 'utf8') : (args.js || 'document.title');
const cdpUrl = args.cdp || 'http://127.0.0.1:9223';
const targets = await listTargets(cdpUrl);
const t = targets.find(x => x.type === 'page' && String(x.url || '').includes('/arena/challenge/proving-ground'))
  || targets.find(x => x.type === 'page' && String(x.url || '').includes('grayswan.ai'));
if (!t) { console.log(JSON.stringify({error: 'no grayswan tab'})); process.exit(1); }
const page = await new CdpPage(t.webSocketDebuggerUrl, 10000).connect();
await page.send('Page.enable');
const result = await page.evaluate(`(() => { try { return ${expr}; } catch (e) { return {__err: String(e)}; } })()`);
console.log(typeof result === 'string' ? result : JSON.stringify(result, null, 1));
page.close();
process.exit(0);
