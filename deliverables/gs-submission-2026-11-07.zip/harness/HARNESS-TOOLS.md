# HARNESS-TOOLS — практический справочник (обновлено 2026-11-06)

Инструменты обвязки поверх штатного адаптера (`harness/hackathon.py arena ...`, доки — `ENGINE.md`).
Все команды — из `workspace`.

## Инструменты

| Инструмент | Назначение | Ключевые примеры |
|---|---|---|
| `harness/farm.py` | Батч-прогон по моделям с чекпойнтом/резюмом, авто-judge на comply | `--dry-run` (только select/bind/inspect — безопасный тест), `--sweep` (свип после раунда), верификация выбора `selected+verified`, авто-retry bind при «model is unknown» |
| `harness/arena_heal.py` | Авто-починки: stale scope → rebind+retry; «verdict is already visible» → CONTINUE + retry; select-fresh | `judge`, `click`, `clear-verdict`, `select-fresh`; журнал `attempts/heal-log.jsonl` |
| `harness/classify_response.py` | Классы ответов: `refuse_template` / `empty_response` / `blocked_filter` / `comply_full` / `comply_short` + pre-judge эвристики | `--batch "artifacts/farm-*-send-result.json"` |
| `harness/arena_chats.py` | Модалка чатов/сабмишенов → JSON | Формат записи: `STATUS\nTODAY h:mmPM\n<превью>\n<сценарий>\n·\n<Модель>`; счётчики: submissions, breaks_total |
| `harness/verdict_sweep.py` | Сверка pending/unknown вердиктов в чекпойнт ферма | **ОБЯЗАТЕЛЬНО** `--scenario-id` (иначе зачёт модели в ДРУГОМ сценарии = ложный апдейт — ловили на OG/BSE) |
| `tools/inspect_texts.py` | Быстрый текст из inspect-дампа | `--filter criteria,chat --max 500` |
| `tools/pptx_dump.py` / `tools/fill_pptx.py` | Разбор и заполнение .pptx | см. навык `presentation-decks` |

## Типовые рецепты

**Раунд ферма:** dry-run (1 модель) → реальный прогон (`--judge-policy comply`, `--pause 20`) → `--sweep` (или отдельно `verdict_sweep.py`) → записи в журнал (`hackathon.py record`).

**Критерии сценария:** `python3 harness/hackathon.py arena show-criteria --target T --out artifacts/criteria-X.json` — самодостаточно, НЕ кликать относительные селекторы вида `div:nth-of-type(3) > button:nth-of-type(2)` из inspect: они матчат первый элемент с таким путём (случайно попали в аватар профиля). Для полного текста элемента — `arena read --target T --selector CSS`.

**Модель «unknown» после навигации:** `arena models` → `arena select-model` (через другую модель и обратно при повторе) → rebind. В farm.py это уже встроено.

**Застрявший вердикт:** `arena_heal.py clear-verdict` (ищет кнопку CONTINUE по короткому тексту) → повторный judge.

**Зависший/пустой свип:** проверить, не показывает ли вкладка Vercel-проверку («Контрольная точка безопасности») — повторить через паузу.

## State-модель (важно)

- Вердикт-баннер может рендерить ТЕКУЩУЮ выбранную модель поверх старых вердиктов — истина в списке SUBMITTED (status+time+model) и бейджах BROKEN.
- `pending` ≠ провал: не ресабмитить, сверять свипом позже.
- После каждой навигации/смены модели — rebind scope (`Scope is stale` лечится heal-ом).
- Дубли отправок запрещены; чекпойнт ферма исключает повторные send (кроме `--retry`).
